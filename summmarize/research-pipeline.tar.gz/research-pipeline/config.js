import "dotenv/config";

export const config = {
  vault: {
    root: process.env.VAULT_ROOT, // /Users/you/Documents/Obsidian/MyVault
    inboxDir: "Research/Processed", // relative to vault root
    digestFile: "Research/_inbox-digest.md",
    sourceTag: "research/inbox", // obsidian collector watches notes with this tag
  },
  raindrop: {
    token: process.env.RAINDROP_TOKEN, // "test token" from raindrop app settings
    collectionId: 0, // 0 = all
  },
  telegram: {
    botToken: process.env.TG_BOT_TOKEN,
    allowedUserId: Number(process.env.TG_ALLOWED_USER_ID), // accept only your forwards
  },
  eliza: {
    token: process.env.ELIZA_TOKEN,
    enrichModel: process.env.ENRICH_MODEL || "glm-4-7", // adjust to actual model id from probe
    fallbackModel: "qwen3-coder",
  },
  enrich: {
    contextSummary:
      "User builds multi-agent AI workflows on macOS centered on Claude Code, " +
      "with model tiers routed through a personal Node.js proxy (Eliza). " +
      "Free models (GLM-4.7, Qwen3-Coder) handle bulk work; paid models for quality-critical tasks. " +
      "Interested in: agent frameworks, memory systems, evaluation, tool-use patterns, " +
      "prompt engineering, multi-agent orchestration, MCP, RAG, model routing.",
  },
  statePath: "./state.json",
};
